function handlePagination(page) {
    if (page === 1) {
      window.location.href = "index.html"; // Replace with the actual path to your first page
    } else if (page === 2) {
      window.location.href = "page1.html"; // Replace with the actual path to your second page
    } else {
      console.error("Invalid page number:", page);
    }
  }
  